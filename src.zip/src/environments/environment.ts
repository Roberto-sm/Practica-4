
export const environment = {
  production: false,
  supabaseUrl: 'https://gjhhkbrflcgypoyrvigb.supabase.c',
  supabaseKey: 'sb_publishable_09-XKLYgbTK4YDuUpCdIhg_Yw0It27U'
};