import { Injectable, signal } from '@angular/core';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { environment } from '../../environments/environment';
import { Gasto, CategoriaGasto, CATEGORIAS } from '../models/gasto.model';

@Injectable({
  providedIn: 'root'
})
export class GastosService {
  private supabase: SupabaseClient;

  gastos = signal<Gasto[]>([]);
  datosEscaneados = signal<Partial<Gasto> | null>(null);

  constructor() {
    // Inicializamos el cliente, pero NO cargamos datos automáticamente aquí.
    this.supabase = createClient(environment.supabaseUrl, environment.supabaseKey);
  }

  // --- LÓGICA DE SUPABASE (Manual: tú decides cuándo llamarla) ---

  async cargarGastos() {
    const { data, error } = await this.supabase
      .from('gastos')
      .select('*')
      .order('fecha', { ascending: false });

    if (error) {
      console.error('Error cargando gastos:', error);
      return;
    }

    const gastosFormateados: Gasto[] = data.map(g => ({
      id: g.id,
      monto: g.monto,
      concepto: g.concepto,
      categoria: g.categoria as CategoriaGasto,
      metodoPago: g.metodo_pago,
      notas: g.notas,
      imagenTicket: g.imagen_ticket,
      fecha: new Date(g.fecha),
      creadoPorIA: g.creado_por_ia
    }));

    this.gastos.set(gastosFormateados);
  }

  async agregarGasto(gasto: Omit<Gasto, 'id'>): Promise<void> {
    const { error } = await this.supabase
      .from('gastos')
      .insert([{
        monto: gasto.monto,
        concepto: gasto.concepto,
        categoria: gasto.categoria,
        metodo_pago: gasto.metodoPago,
        notas: gasto.notas || null,
        imagen_ticket: gasto.imagenTicket || null,
        creado_por_ia: gasto.creadoPorIA || false,
        fecha: new Date(gasto.fecha).toISOString()
      }]);

    if (error) {
      alert('Error al guardar en BD: ' + error.message);
      return;
    }
    // Recargamos solo después de una acción exitosa
    await this.cargarGastos();
  }

  async eliminarGasto(id: string) {
    const { error } = await this.supabase.from('gastos').delete().eq('id', id);
    if (!error) {
      await this.cargarGastos();
    }
  }

  // --- LÓGICA DEL ESCÁNER (Independiente) ---

  setDatosEscaneados(datos: Partial<Gasto>) {
    this.datosEscaneados.set(datos);
  }

  clearDatosEscaneados() {
    this.datosEscaneados.set(null);
  }

  // --- FUNCIONES AUXILIARES (Sin dependencias de red) ---

  gastosRecientes() {
    return this.gastos().slice(0, 5);
  }

  totalMes() {
    const mesActual = new Date().getMonth();
    return this.gastos()
      .filter(g => new Date(g.fecha).getMonth() === mesActual)
      .reduce((sum, g) => sum + g.monto, 0);
  }

  totalPorCategoria() {
    const categoriasMap = new Map<string, number>();
    let totalGeneral = 0;

    this.gastos().forEach(g => {
      const totalCat = categoriasMap.get(g.categoria) || 0;
      categoriasMap.set(g.categoria, totalCat + g.monto);
      totalGeneral += g.monto;
    });

    return Array.from(categoriasMap.entries()).map(([categoriaId, total]) => {
      const categoriaObj = CATEGORIAS.find(c => c.id === categoriaId) || {
        id: categoriaId as CategoriaGasto, 
        nombre: 'Otros',
        icono: 'ellipsis-horizontal',
        color: '#9ca3af'
      };

      return {
        categoria: categoriaObj,
        total,
        porcentaje: totalGeneral > 0 ? (total / totalGeneral) * 100 : 0
      };
    }).sort((a, b) => b.total - a.total); 
  }

  formatearMonto(monto: number): string {
    return new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(monto);
  }

  formatearFecha(fecha: Date | string): string {
    return new Intl.DateTimeFormat('es-MX', { 
      day: '2-digit', 
      month: 'short', 
      year: 'numeric' 
    }).format(new Date(fecha));
  }
}