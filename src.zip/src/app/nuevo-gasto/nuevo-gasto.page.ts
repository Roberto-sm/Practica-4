import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { IonHeader, IonToolbar, IonTitle, IonContent, IonItem, IonLabel, IonInput, IonSelect, IonSelectOption, IonButton, IonButtons, IonBackButton, IonChip, IonIcon, LoadingController } from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { scanOutline } from 'ionicons/icons';
import { GastosService } from '../services/gastos.service';

@Component({
  selector: 'app-nuevo-gasto',
  templateUrl: 'nuevo-gasto.page.html',
  styleUrls: ['nuevo-gasto.page.scss'],
  standalone: true,
  imports: [IonHeader, IonToolbar, IonTitle, IonContent, IonItem, IonLabel, IonInput, IonSelect, IonSelectOption, IonButton, IonButtons, IonBackButton, IonChip, IonIcon, FormsModule],
})
export class NuevoGastoPage {
  private gastosService = inject(GastosService);
  private router = inject(Router);
  private loadingCtrl = inject(LoadingController);

  gasto: any = {
    concepto: '',
    monto: null,
    categoria: 'otros',
    metodoPago: 'efectivo',
    notas: ''
  };
  
  fechaStr: string = new Date().toISOString();
  
  categorias: any[] = [
    { id: 'comida', nombre: 'Comida' },
    { id: 'transporte', nombre: 'Transporte' },
    { id: 'servicios', nombre: 'Servicios' },
    { id: 'otros', nombre: 'Otros' }
  ];

  constructor() {
    addIcons({ scanOutline });
  }

  ionViewWillEnter() {
    // Así se lee un "signal" en Angular moderno
    const datosIA = this.gastosService.datosEscaneados();
    
    if (datosIA && datosIA.monto) {
      this.gasto.concepto = datosIA.concepto;
      this.gasto.monto = datosIA.monto;
      this.gasto.categoria = datosIA.categoria;
      
      // Limpiamos usando tu función exacta del servicio
      this.gastosService.clearDatosEscaneados();
    }
  }

  setMetodoPago(metodo: string) {
    this.gasto.metodoPago = metodo;
  }

  isFormValid(): boolean {
    return !!(this.gasto.concepto && this.gasto.monto > 0 && this.gasto.categoria);
  }

  cancelar() {
    this.router.navigate(['/tabs/inicio']); // O la ruta a tu inicio
  }

  irAEscanear() {
    this.router.navigate(['/tabs/escanear']);
  }

  async guardarGasto() {
    if (!this.isFormValid()) return;

    const loading = await this.loadingCtrl.create({ message: 'Guardando...' });
    await loading.present();

    this.gasto.fecha = new Date(this.fechaStr);

    try {
      await this.gastosService.agregarGasto(this.gasto);
      await loading.dismiss();
      alert("¡Gasto guardado con éxito!");
      
      this.gasto = { concepto: '', monto: null, categoria: 'otros', metodoPago: 'efectivo', notas: '' };
      this.cancelar();
      
    } catch (error) {
      await loading.dismiss();
      console.error(error);
      alert("Hubo un error al guardar.");
    }
  }
}