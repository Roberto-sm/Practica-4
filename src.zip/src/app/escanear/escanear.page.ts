import { Component, ElementRef, ViewChild, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonButton, IonIcon, LoadingController } from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { cameraOutline, imagesOutline, sparkles, refreshOutline } from 'ionicons/icons';
import { GastosService } from '../services/gastos.service';
import { CategoriaGasto } from '../models/gasto.model';

@Component({
  selector: 'app-escanear',
  templateUrl: 'escanear.page.html',
  standalone: true,
  imports: [IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonButton, IonIcon],
})
export class EscanearPage {
  @ViewChild('fileInput', { static: false }) fileInput?: ElementRef<HTMLInputElement>;

  private router = inject(Router);
  private gastosService = inject(GastosService);
  private loadingCtrl = inject(LoadingController);

  imagenCapturada = signal<string | null>(null);
  private imagenBase64Pura: string | null = null;
  private mimeType: string = 'image/jpeg';
  
  // Tu llave de OpenRouter
  private openRouterKey = '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';

  constructor() {
    addIcons({ cameraOutline, imagesOutline, sparkles, refreshOutline });
  }

  // --- LÓGICA DE CÁMARA INDEPENDIENTE ---
  tomarFoto(): void {
    // Esto activa el input invisible del HTML, abriendo cámara o galería
    this.fileInput?.nativeElement.click();
  }

  cargarDesdeNavegador(event: any): void {
    const file = event.target.files[0];
    if (!file) return;

    this.mimeType = file.type;
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      this.imagenBase64Pura = result.split(',')[1];
      this.imagenCapturada.set(result);
    };
    reader.readAsDataURL(file);
  }

  // --- LÓGICA DE IA ---
  async analizarConIA(): Promise<void> {
    if (!this.imagenBase64Pura) {
      alert("Por favor, selecciona una foto primero.");
      return;
    }
    
    const loading = await this.loadingCtrl.create({ message: 'Analizando ticket...' });
    await loading.present();

    try {
      const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.openRouterKey}`,
          'HTTP-Referer': 'http://localhost:8100',
          'X-Title': 'Proyecto DPS'
        },
        body: JSON.stringify({
          model: 'google/gemini-2.0-flash-lite-preview:free',
          messages: [
            {
              role: 'user',
              content: [
                { type: 'text', text: 'Analiza este ticket. Responde SOLO en formato JSON. Formato: {"concepto": "Nombre", "monto": 0.00, "categoria": "comida"}' },
                { type: 'image_url', image_url: { url: `data:${this.mimeType};base64,${this.imagenBase64Pura}` } }
              ]
            }
          ]
        })
      });

      if (!response.ok) throw new Error('Error al conectar con la IA');

      const result = await response.json();
      let text = result.choices[0].message.content.replace(/```json|```/g, '').trim();
      const data = JSON.parse(text);

      // Guardamos en el servicio (pasivo, no guarda en BD aún)
      this.gastosService.setDatosEscaneados({
        monto: Number(data.monto) || 0,
        concepto: data.concepto || 'Ticket',
        categoria: (data.categoria as CategoriaGasto) || 'otros',
        creadoPorIA: true
      });

      await loading.dismiss();
      this.router.navigate(['/tabs/nuevo-gasto']); 
    } catch (e: any) {
      await loading.dismiss();
      console.error("Error:", e);
      alert("Error en la IA. Intenta de nuevo.");
    }
  }

  reiniciar(): void { 
    this.imagenCapturada.set(null); 
    this.imagenBase64Pura = null;
    if (this.fileInput?.nativeElement) {
      this.fileInput.nativeElement.value = '';
    }
  }
}