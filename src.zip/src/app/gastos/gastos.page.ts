import { Component, inject, signal, computed } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonButton,
  IonIcon,
  IonSearchbar,
  IonChip,
  IonList,
  IonItem,
  IonItemSliding,
  IonItemOptions,
  IonItemOption,
  IonLabel,
  IonNote,
  IonBadge,
  IonFab,
  IonFabButton,
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  wallet,
  searchOutline,
  trashOutline,
  add,
  receiptOutline,
  restaurant,
  car,
  flash,
  medkit,
  ellipsisHorizontal,
} from 'ionicons/icons';
import { GastosService } from '../services/gastos.service';
import { CategoriaGasto, CATEGORIAS, Gasto } from '../models/gasto.model';

@Component({
  selector: 'app-gastos',
  templateUrl: 'gastos.page.html',
  styleUrls: ['gastos.page.scss'],
  standalone: true,
  imports: [
    FormsModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonButtons,
    IonButton,
    IonIcon,
    IonSearchbar,
    IonChip,
    IonList,
    IonItem,
    IonItemSliding,
    IonItemOptions,
    IonItemOption,
    IonLabel,
    IonNote,
    IonBadge,
    IonFab,
    IonFabButton,
  ],
})
export class GastosPage {
  gastosService = inject(GastosService);
  private router = inject(Router);

  searchTerm = '';
  filtroActivo = signal<CategoriaGasto | 'todos'>('todos');

  constructor() {
    addIcons({
      wallet,
      searchOutline,
      trashOutline,
      add,
      receiptOutline,
      restaurant,
      car,
      flash,
      medkit,
      ellipsisHorizontal,
    });
  }

  gastosFiltrados = computed(() => {
    let gastos = this.gastosService.gastos();
    
    if (this.filtroActivo() !== 'todos') {
      gastos = gastos.filter(g => g.categoria === this.filtroActivo());
    }
    
    if (this.searchTerm.trim()) {
      const term = this.searchTerm.toLowerCase();
      gastos = gastos.filter(g => 
        g.concepto.toLowerCase().includes(term)
      );
    }
    
    return gastos;
  });

  setFiltro(filtro: CategoriaGasto | 'todos'): void {
    this.filtroActivo.set(filtro);
  }

  buscar(event: any): void {
    this.searchTerm = event.target.value || '';
  }

  getCategoriaIcon(categoria: CategoriaGasto): string {
    return CATEGORIAS.find(c => c.id === categoria)?.icono || 'ellipsis-horizontal';
  }

  getCategoriaColor(categoria: CategoriaGasto): string {
    return CATEGORIAS.find(c => c.id === categoria)?.color || '#8B5CF6';
  }

  getCategoriaNombre(categoria: CategoriaGasto): string {
    return CATEGORIAS.find(c => c.id === categoria)?.nombre || 'Otros';
  }

  eliminarGasto(id: string): void {
    this.gastosService.eliminarGasto(id);
  }

  irANuevoGasto(): void {
    this.router.navigate(['/nuevo-gasto']);
  }
}
