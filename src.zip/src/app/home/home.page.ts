import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonButton,
  IonIcon,
  IonList,
  IonItem,
  IonLabel,
  IonNote,
  IonFab,
  IonFabButton,
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  wallet,
  searchOutline,
  notificationsOutline,
  trendingUp,
  walletOutline,
  receiptOutline,
  restaurantOutline,
  cameraOutline,
  chevronForward,
  add,
  restaurant,
  car,
  flash,
  medkit,
  ellipsisHorizontal,
} from 'ionicons/icons';
import { GastosService } from '../services/gastos.service';
import { CategoriaGasto, CATEGORIAS } from '../models/gasto.model';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  imports: [
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonButtons,
    IonButton,
    IonIcon,
    IonList,
    IonItem,
    IonLabel,
    IonNote,
    IonFab,
    IonFabButton,
  ],
})
export class HomePage {
  gastosService = inject(GastosService);
  private router = inject(Router);

  constructor() {
    addIcons({
      wallet,
      searchOutline,
      notificationsOutline,
      trendingUp,
      walletOutline,
      receiptOutline,
      restaurantOutline,
      cameraOutline,
      chevronForward,
      add,
      restaurant,
      car,
      flash,
      medkit,
      ellipsisHorizontal,
    });
  }

  getTopCategoria(): string {
    const resumen = this.gastosService.totalPorCategoria();
    if (resumen.length > 0) {
      return resumen[0].categoria.nombre;
    }
    return 'N/A';
  }

  getCategoriaIcon(categoria: CategoriaGasto): string {
    return CATEGORIAS.find(c => c.id === categoria)?.icono || 'ellipsis-horizontal';
  }

  getCategoriaColor(categoria: CategoriaGasto): string {
    return CATEGORIAS.find(c => c.id === categoria)?.color || '#8B5CF6';
  }

  irAEscanear(): void {
    this.router.navigate(['/escanear']);
  }

  irAGastos(): void {
    this.router.navigate(['/gastos']);
  }

  irANuevoGasto(): void {
    this.router.navigate(['/nuevo-gasto']);
  }
}
