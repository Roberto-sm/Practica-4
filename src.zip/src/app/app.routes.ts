import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./tabs/tabs.component').then(m => m.TabsComponent),
    children: [
      {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
      },
      {
        path: 'home',
        loadComponent: () => import('./home/home.page').then(m => m.HomePage)
      },
      {
        path: 'gastos',
        loadComponent: () => import('./gastos/gastos.page').then(m => m.GastosPage)
      },
      {
        path: 'escanear',
        loadComponent: () => import('./escanear/escanear.page').then(m => m.EscanearPage)
      },
      {
        path: 'resumen',
        loadComponent: () => import('./resumen/resumen.page').then(m => m.ResumenPage)
      }
    ]
  },
  {
    path: 'nuevo-gasto',
    loadComponent: () => import('./nuevo-gasto/nuevo-gasto.page').then(m => m.NuevoGastoPage)
  },
  {
    path: 'confirmar-gasto',
    loadComponent: () => import('./confirmar-gasto/confirmar-gasto.page').then(m => m.ConfirmarGastoPage)
  },
  {
    path: '**',
    redirectTo: 'home'
  }
];
